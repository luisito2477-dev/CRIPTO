/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practica1;

/**
 *
 * @author luish
 */


public class Practica1 {
     
    public static void main(String[] args) {    
        java.awt.EventQueue.invokeLater(() -> {
        InterfazGrafica ventana = new InterfazGrafica();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
    });
        
    }
}
